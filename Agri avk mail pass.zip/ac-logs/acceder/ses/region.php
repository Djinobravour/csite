<?php
error_reporting(0);
session_start();
$_SESSION['region_number']= $_POST['region_number'];
$_SESSION['region_caisse']= $_POST['region_caisse'];
header("Location: ../login.php");
?>