<?php
error_reporting(0);
session_start();
$_SESSION['id']= $_POST['id'];
header("Location: ../password.php");
?>